import os

def handler(event, ctx):
    name = os.environ.get("NAME", "World")
    return {
        "statusCode": 200,
        "body": "Hello World"
    }